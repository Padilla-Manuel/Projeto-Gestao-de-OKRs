// 'use client';

// import { useState } from 'react';
// import { useRouter } from 'next/navigation';
// import BotaoVoltar from '@/app/components/BotaoVoltar';
// import styles from '../../page.module.css'; // importa o CSS principal

// export default function NovoObjetivoPage() {
//   const [titulo, setTitulo] = useState('');
//   const [descricao, setDescricao] = useState('');
//   const router = useRouter();

//   async function handleSubmit(e) {
//     e.preventDefault();

//     const response = await fetch('http://localhost:8080/api/objetivos', {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify({
//         titulo,
//         descricao,
//         porcentagemConclusao: 0,
//       }),
//     });

//     if (response.ok) {
//       router.push('/objetivos'); // redireciona após salvar
//     } else {
//       alert('Erro ao salvar o objetivo.');
//     }
//   }

//   return (
//     <main className={styles.main}>
//       <div className={styles.card}>
//         <h2>Novo Objetivo</h2>

//         {/* Botão de voltar fora do formulário */}
//         <BotaoVoltar />

//         <form onSubmit={handleSubmit} className={styles.formulario}>
//           <input
//             type="text"
//             className={styles.campoInput}
//             placeholder="Título"
//             value={titulo}
//             onChange={(e) => setTitulo(e.target.value)}
//             required
//           />

//           <textarea
//             className={styles.campoInput}
//             placeholder="Descrição"
//             value={descricao}
//             onChange={(e) => setDescricao(e.target.value)}
//             required
//           />

//           <button type="submit" className={styles.botao}>
//             Salvar Objetivo
//           </button>
//         </form>
//       </div>
//     </main>
//   );
// }

package com.teckmack.gestor_okrs.service;

import com.teckmack.gestor_okrs.model.Iniciativa;
import com.teckmack.gestor_okrs.model.ResultadoChave;
import com.teckmack.gestor_okrs.repository.IniciativaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Serviço responsável pela manipulação das Iniciativas e atualização das porcentagens de conclusão dos Resultados Chave.
 */
@Service
public class IniciativaService {

    @Autowired
    private IniciativaRepository iniciativaRepository;

    @Autowired
    private ResultadoChaveService resultadoChaveService;

    /**
     * Retorna todas as Iniciativas.
     *
     * @return Lista de Iniciativas.
     */
    public List<Iniciativa> listarTodos() {
        return iniciativaRepository.findAll();
    }

    /**
     * Busca uma Iniciativa pelo seu ID.
     *
     * @param id ID da Iniciativa.
     * @return Iniciativa encontrada, se existir.
     */
    public Optional<Iniciativa> buscarPorId(Long id) {
        return iniciativaRepository.findById(id);
    }

    /**
     * Salva uma nova Iniciativa ou atualiza uma Iniciativa existente. 
     * Após a criação ou atualização, também atualiza a porcentagem de conclusão do Resultado Chave relacionado.
     *
     * @param iniciativa Objeto com os dados da Iniciativa a ser salva.
     * @return Iniciativa salva.
     */
    public Iniciativa salvar(Iniciativa iniciativa) {
        Iniciativa salva = iniciativaRepository.save(iniciativa);

        // Atualiza o ResultadoChave relacionado
        ResultadoChave resultadoChave = salva.getResultadoChave();
        if (resultadoChave != null) {
            resultadoChaveService.atualizarPorcentagemConclusao(resultadoChave);
        }

        return salva;
    }

    /**
     * Deleta uma Iniciativa pelo seu ID.
     * Após a exclusão, também atualiza a porcentagem de conclusão do Resultado Chave relacionado.
     *
     * @param id ID da Iniciativa a ser deletada.
     */
    public void deletar(Long id) {
        Optional<Iniciativa> iniciativaOpt = iniciativaRepository.findById(id);
        if (iniciativaOpt.isPresent()) {
            Iniciativa iniciativa = iniciativaOpt.get();
            ResultadoChave resultadoChave = iniciativa.getResultadoChave();
            iniciativaRepository.deleteById(id);

            if (resultadoChave != null) {
                resultadoChaveService.atualizarPorcentagemConclusao(resultadoChave);
            }
        }
    }
}

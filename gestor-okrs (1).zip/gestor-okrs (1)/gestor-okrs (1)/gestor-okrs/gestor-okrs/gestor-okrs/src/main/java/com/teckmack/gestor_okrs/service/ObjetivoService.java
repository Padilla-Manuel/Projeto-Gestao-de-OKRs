package com.teckmack.gestor_okrs.service;

import com.teckmack.gestor_okrs.model.Objetivo;
import com.teckmack.gestor_okrs.model.ResultadoChave;
import com.teckmack.gestor_okrs.repository.ObjetivoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Serviço responsável pela manipulação dos Objetivos e cálculo de porcentagem de conclusão.
 */
@Service
public class ObjetivoService {

    @Autowired
    private ObjetivoRepository objetivoRepository;

    /**
     * Retorna todos os Objetivos.
     *
     * @return Lista de Objetivos.
     */
    public List<Objetivo> listarTodos() {
        return objetivoRepository.findAll();
    }

    /**
     * Busca um Objetivo pelo seu ID.
     *
     * @param id ID do Objetivo.
     * @return Objetivo encontrado, se existir.
     */
    public Optional<Objetivo> buscarPorId(Long id) {
        return objetivoRepository.findById(id);
    }

    /**
     * Salva um novo Objetivo ou atualiza um Objetivo existente.
     *
     * @param objetivo Objeto com os dados do Objetivo a ser salvo.
     * @return Objetivo salvo.
     */
    public Objetivo salvar(Objetivo objetivo) {
        return objetivoRepository.save(objetivo);
    }

    /**
     * Deleta um Objetivo pelo seu ID.
     *
     * @param id ID do Objetivo a ser deletado.
     */
    public void deletar(Long id) {
        objetivoRepository.deleteById(id);
    }

    /**
     * Calcula a porcentagem de conclusão de um Objetivo com base nos Resultados Chave associados.
     *
     * @param objetivo Objeto Objetivo.
     * @return Porcentagem de conclusão calculada.
     */
    public double calcularPorcentagemConclusao(Objetivo objetivo) {
        List<ResultadoChave> resultados = objetivo.getResultadosChave();
        if (resultados == null || resultados.isEmpty()) {
            return 0;
        }

        double somaPorcentagem = 0;
        for (ResultadoChave resultado : resultados) {
            somaPorcentagem += resultado.getPorcentagemConclusao();
        }

        return somaPorcentagem / resultados.size();
    }

    /**
     * Atualiza a porcentagem de conclusão de um Objetivo.
     *
     * @param objetivo Objeto Objetivo que será atualizado.
     */
    public void atualizarPorcentagemConclusao(Objetivo objetivo) {
        double novaPorcentagem = calcularPorcentagemConclusao(objetivo);
        objetivo.setPorcentagemConclusao(novaPorcentagem);
        objetivoRepository.save(objetivo);
    }

    /**
     * Calcula a porcentagem de conclusão de um Objetivo pelo seu ID.
     *
     * @param id ID do Objetivo.
     * @return Porcentagem de conclusão calculada.
     */
    public double calcularPorcentagemConclusao(Long id) {
        Optional<Objetivo> objetivoOpt = buscarPorId(id);
        if (objetivoOpt.isPresent()) {
            return calcularPorcentagemConclusao(objetivoOpt.get());
        }
        return 0;
    }
}

package com.teckmack.gestor_okrs.service;

import com.teckmack.gestor_okrs.model.Iniciativa;
import com.teckmack.gestor_okrs.model.ResultadoChave;
import com.teckmack.gestor_okrs.repository.ResultadoChaveRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Serviço responsável pela manipulação e cálculo dos Resultados Chave (Key Results).
 */
@Service
public class ResultadoChaveService {

    @Autowired
    private ResultadoChaveRepository resultadoChaveRepository;

    @Autowired
    private ObjetivoService objetivoService;

    /**
     * Retorna todos os Resultados Chave.
     *
     * @return Lista de Resultados Chave.
     */
    public List<ResultadoChave> listarTodos() {
        return resultadoChaveRepository.findAll();
    }

    /**
     * Busca um Resultado Chave pelo seu ID.
     *
     * @param id ID do Resultado Chave.
     * @return Resultado Chave encontrado, se existir.
     */
    public Optional<ResultadoChave> buscarPorId(Long id) {
        return resultadoChaveRepository.findById(id);
    }

    /**
     * Salva um novo Resultado Chave ou atualiza um existente.
     *
     * @param resultadoChave Objeto com os dados do Resultado Chave a ser salvo.
     * @return Resultado Chave salvo.
     */
    public ResultadoChave salvar(ResultadoChave resultadoChave) {
        return resultadoChaveRepository.save(resultadoChave);
    }

    /**
     * Deleta um Resultado Chave pelo seu ID.
     *
     * @param id ID do Resultado Chave a ser deletado.
     */
    public void deletar(Long id) {
        resultadoChaveRepository.deleteById(id);
    }

    /**
     * Calcula a porcentagem de conclusão de um Resultado Chave com base nas iniciativas associadas.
     *
     * @param resultadoChaveId ID do Resultado Chave.
     * @return Porcentagem de conclusão calculada.
     */
    public double calcularPorcentagemConclusao(Long resultadoChaveId) {
        Optional<ResultadoChave> resultadoChaveOpt = resultadoChaveRepository.findById(resultadoChaveId);
        return resultadoChaveOpt.map(this::calcularPorcentagemConclusao).orElse(0.0);
    }

    /**
     * Calcula a porcentagem de conclusão de um Resultado Chave com base nas iniciativas associadas.
     *
     * @param resultadoChave Objeto Resultado Chave.
     * @return Porcentagem de conclusão calculada.
     */
    public double calcularPorcentagemConclusao(ResultadoChave resultadoChave) {
        List<Iniciativa> iniciativas = resultadoChave.getIniciativas();
        if (iniciativas == null || iniciativas.isEmpty()) {
            return 0;
        }

        double somaPorcentagem = 0;
        for (Iniciativa iniciativa : iniciativas) {
            somaPorcentagem += iniciativa.getPorcentagemConclusao();
        }

        return somaPorcentagem / iniciativas.size();
    }

    /**
     * Atualiza a porcentagem de conclusão de um Resultado Chave e também do Objetivo relacionado.
     *
     * @param resultadoChave Objeto Resultado Chave que será atualizado.
     */
    public void atualizarPorcentagemConclusao(ResultadoChave resultadoChave) {
        double novaPorcentagem = calcularPorcentagemConclusao(resultadoChave);
        resultadoChave.setPorcentagemConclusao(novaPorcentagem);
        resultadoChaveRepository.save(resultadoChave);

        // Atualiza o objetivo relacionado também
        if (resultadoChave.getObjetivo() != null) {
            objetivoService.atualizarPorcentagemConclusao(resultadoChave.getObjetivo());
        }
    }
}

package com.teckmack.gestor_okrs.repository;

import com.teckmack.gestor_okrs.model.Iniciativa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IniciativaRepository extends JpaRepository<Iniciativa, Long> {
}
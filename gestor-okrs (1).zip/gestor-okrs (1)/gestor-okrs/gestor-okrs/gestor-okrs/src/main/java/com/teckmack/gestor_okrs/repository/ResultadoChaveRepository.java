package com.teckmack.gestor_okrs.repository;

import com.teckmack.gestor_okrs.model.ResultadoChave;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultadoChaveRepository extends JpaRepository<ResultadoChave, Long> {
}
package com.teckmack.gestor_okrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorOkrsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.teckmack.gestor_okrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestorOkrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestorOkrsApplication.class, args);
	}

}
